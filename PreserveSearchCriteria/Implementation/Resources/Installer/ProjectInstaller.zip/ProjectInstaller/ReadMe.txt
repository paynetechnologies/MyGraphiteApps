Steps to create a Project Installer:
1. If Inno Setup is not available install from http://www.jrsoftware.org/isinfo.php
2. Open ProjectInstallScript.iss file
3. Replace $$$Username$$$ with user folder name in C:\Users
3. Replace $$$ProjectName$$$ with GraphiteGTCGuide Project name
4. Compile the script file - Setup exe will be in the Resources\Installer folder
